interface Window {
  NativeEventSource: any;
  EventSourcePolyfill: any;
}
