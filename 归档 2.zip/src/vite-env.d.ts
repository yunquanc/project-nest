/// <reference types="vite/client" />
declare module '@ckeditor/ckeditor5-inspector'