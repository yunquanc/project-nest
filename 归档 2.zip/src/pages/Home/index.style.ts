import { createStyles } from "antd-style";

const useStyles = createStyles(() => ({
  container: {},
}));

export default useStyles;
