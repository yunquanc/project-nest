import { createStyles, css } from "antd-style";

export default createStyles({
  content: {
    width: "100%",
    height: "100%",
    backgroundColor: "#fff",
  },
});
